# Dylan Murdoch — Personal Context

## The basics
- **Name**: Dylan Murdoch
- **Age**: 31
- **Birthday**: February 24, 1995
- **Location**: Eagle Mountain, Utah
- **Family**: Wife + kids (dirt bike rides after work = family time he protects)

## Career
- **Current job**: Real estate agent, license held at Red Rock Real Estate
- **Represents**: Narwhal Homes (new construction tract builder, Utah County) + Hawkstone Homes (their custom/luxury line)
- **Experience**: 8-9 years in real estate, heavily focused on new construction
- **Honest take**: Real estate is the income engine right now, not the passion. It's the means to fund the bigger vision.

## The real vision
Dylan is deeply entrepreneurial. He has a mind that constantly runs simulations on business ideas. His actual goal is to build an AI-powered business (or multiple) that generates enough income to work fully remote, automate operations, and build real financial freedom. AI is not a hobby — it's the mission.

**He wants to:**
- Learn AI tools deeply and fast
- Build and launch products
- Generate real revenue from AI within 90 days
- Eventually replace or dramatically reduce his dependence on the real estate income

## Current tools
- Google Calendar
- Gmail
- Google Drive
- Lindy.ai (current automation tool for Narwhal business — loves it)

## Daily rhythm
- **Wake up**: ~7:45 AM
- **Arrive at work**: ~9:30 AM
- **Leave work**: ~6:00–6:30 PM
- **Evenings**: Family time, dirt bike rides, kids — this is sacred
- **Night**: Vibe coding / building with Jarvis — this is his creative and build time

## Personality
- High energy, entrepreneurial, idea-driven
- Hates bureaucracy and slow processes
- Loves running mental simulations on ideas
- Wants to improve in every area — physically, mentally, as a father, as a builder
- Emotionally aware enough to want check-ins — not just productivity, but wellbeing

## Current stressors
1. Real estate business performance — needs to stay strong while he builds on the side
2. Fear of missing the AI wave — wants to move fast and not fall behind
3. Knowing what to build first and how to prioritize the million ideas in his head

## What success looks like in 90 days
- Has launched at least one AI product generating real revenue
- Has a clear portfolio of ideas ranked by potential
- Jarvis is deeply integrated into his daily workflow
- Real estate is running smoothly with minimal manual effort
- He feels less overwhelmed and more in control
